# 部署说明

本目录包含了完整的演示系统文件，可以直接部署到任何静态文件服务器。

## 文件清单
- index.html - 主页面文件
- package.json - 项目配置
- README.md - 项目说明
- scripts/ - JavaScript文件目录
- styles/ - CSS样式文件目录

## 部署步骤
1. 将整个dist目录上传到服务器
2. 确保web服务器配置正确
3. 访问index.html即可

构建时间: 2025/7/24 18:19:53
